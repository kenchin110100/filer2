=========
filer2
=========
* file edit library for python2

usage
=========

* from filer2 import Filer
* f = Filer()
* list_csv = f.readcsv(path)

list-usage
=========

* readcsv
* writecsv
* readtsv
* writetsv
* readtxt
* writetxt
* readdump
* writedump